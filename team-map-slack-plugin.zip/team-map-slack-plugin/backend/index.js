
const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
const dotenv = require("dotenv");
const tzlookup = require("tz-lookup");
const { DateTime } = require("luxon");
const geo = require("node-geocoder")({ provider: "openstreetmap" });

dotenv.config();
const app = express();
app.use(cors());

const SLACK_TOKEN = process.env.SLACK_BOT_TOKEN;

app.get("/api/team", async (req, res) => {
  const slackRes = await fetch("https://slack.com/api/users.list", {
    headers: { Authorization: `Bearer ${SLACK_TOKEN}` },
  });
  const { members } = await slackRes.json();

  const results = await Promise.all(
    members
      .filter((m) => !m.deleted && !m.is_bot)
      .map(async (user) => {
        const profile = user.profile;
        const city = profile.fields?.XfXXXXXXX?.value || "unknown";
        const geodata = await geo.geocode(city);
        const { latitude: lat, longitude: lng } = geodata[0] || {};
        const tz = tzlookup(lat, lng);
        const time = DateTime.now().setZone(tz).toFormat("hh:mm a");

        return {
          id: user.id,
          name: profile.real_name,
          image: profile.image_72,
          city,
          time,
          lat,
          lng,
        };
      })
  );

  res.json(results);
});

app.listen(3001, () => console.log("Backend running on port 3001"));
